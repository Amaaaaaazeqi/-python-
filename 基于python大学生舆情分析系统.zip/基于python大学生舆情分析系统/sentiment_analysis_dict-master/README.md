# 简介
1、本项目是在python3.6基础上做的。  
2、本项目为中文的文本情感分析，为多文本分类，一共3个标签：1、0、-1，分别表示正面、中面和负面的情感。    
3、欢迎大家联系我 www.hellonlp.com  
 
 # 使用方法 
 1、预测  
 python preidict.py 
 
 # 知乎代码解读
https://zhuanlan.zhihu.com/p/142011031
